gen = {"Male":1,"Female":2}
loc = {'New York City': 1, 'Los Angeles': 2, 'Chicago': 3, 'Miami': 4, 'Seattle': 5, 'Atlanta': 6, 'Houston': 7, 'Washington': 8, 'Orlando': 9, 'San Francisco': 10, 'Dallas': 11, 'Las Vegas': 12, 'Boston': 13, 'Denver': 14, 'Philadelphia': 15}
med = {'Diabetes': 1, 'Heart Disease': 2, 'None': -1, 'Cancer': 3, 'Asthma': 4, 'Back Pain': 5, 'Multiple Conditions': 6}
pol = {'PPO':1,'HMO':2,'Bronze':3,'Silver':4,'Gold':5,'Platanium':6}
dia= {'E11.1':1,'F21.4':2,'D13.5':3,'F24.7':4,'A67.3':5,'B97.8':6,'C08.4':7,'E10.3':8,'D36.9':9}
pla = {'Hospital':1,'Clinic':2,'Urgent Care':3,'In Network Doctor':4,'Out of Network Specialist':5,'Retail Clinic':6}
spe = {'Cardiology': 1, 'Internal Medicine': 2, 'Orthopedics': 3, 'Oncology': 4, 'Pulmonology': 5, 'Physical Therapy': 6, 'Family Medicine': 7, 'Ophthalmology': 8, 'Dermatology': 9, 'Endocrinology': 10, 'Gastroenterology': 11, 'Pediatrics': 12, 'Neurology': 13}
mapss = {"Gender":gen,"Location":loc,"Medical History":med,"Policy Type":pol,"Diagnosis Codes":dia,"Place Of Service":pla,"Specialization":spe}